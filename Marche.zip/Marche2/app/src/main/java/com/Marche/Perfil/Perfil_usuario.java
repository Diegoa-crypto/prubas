package com.Marche.Perfil;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.Marche.R;

public class Perfil_usuario extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_usuario);
    }
}
